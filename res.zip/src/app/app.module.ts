import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { JsonpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { Storage } from '@ionic/storage';

import { AgendaPage } from '../pages/agenda/agenda';
// import { BestuurPage } from '../pages/bestuur/bestuur';
import { ContactPage } from '../pages/contact/contact';
import { FotoalbumPage } from '../pages/fotoalbum/fotoalbum';
import { HomePage } from '../pages/home/home';
import { LedenPage } from '../pages/leden/leden';
import { MembershipPage } from '../pages/membership/membership';
import { NieuwsPage } from '../pages/nieuws/nieuws';
import { NieuwsbriefRegistrerenPage } from '../pages/nieuwsbrief-registreren/nieuwsbrief-registreren';
import { SmoelenboekPage } from '../pages/smoelenboek/smoelenboek';

import { EventDetailPage } from '../pages/event-detail/event-detail';
import { NieuwsDetailPage } from '../pages/nieuws-detail/nieuws-detail';
import { GalleryDetailPage } from '../pages/gallery-detail/gallery-detail';
import { LedenDetailPage } from '../pages/leden-detail/leden-detail';
import { GallerySlidesPage } from '../pages/gallery-slides/gallery-slides';
import { SmoelenboekDetailPage } from '../pages/smoelenboek-detail/smoelenboek-detail';
import { TermAndConditionsPage } from '../pages/term-and-condition/term-and-condition';

@NgModule({
  declarations: [
    MyApp,
    AgendaPage,
    // BestuurPage,
    ContactPage,
    FotoalbumPage,
    HomePage,
    LedenPage,
    MembershipPage,
    NieuwsPage,
    NieuwsbriefRegistrerenPage,
    SmoelenboekPage,
    EventDetailPage,
    NieuwsDetailPage,
    GalleryDetailPage,
    LedenDetailPage,
    GallerySlidesPage,
    SmoelenboekDetailPage, 
    TermAndConditionsPage
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    JsonpModule,
    FormsModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AgendaPage,
    // BestuurPage,
    ContactPage,
    FotoalbumPage,
    HomePage,
    LedenPage,
    MembershipPage,
    NieuwsPage,
    NieuwsbriefRegistrerenPage,
    SmoelenboekPage,
    EventDetailPage,
    NieuwsDetailPage,
    GalleryDetailPage,
    LedenDetailPage,
    GallerySlidesPage,
    SmoelenboekDetailPage,
    TermAndConditionsPage

  ],
  providers: [
    {provide: ErrorHandler, useClass: IonicErrorHandler}, 
    Storage
  ]
})
export class AppModule {}
