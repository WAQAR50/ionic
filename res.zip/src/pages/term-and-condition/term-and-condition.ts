import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, MenuController, ViewController, ModalController } from 'ionic-angular';
import { Http } from '@angular/http';

/*
  Generated class for the Membership page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/


@Component({
  selector: 'page-term-conditions',
  templateUrl: 'term-and-condition.html'
})
export class TermAndConditionsPage {
  constructor(public viewCtrl: ViewController) {}

  closeModal() {
    this.viewCtrl.dismiss();
  }
}