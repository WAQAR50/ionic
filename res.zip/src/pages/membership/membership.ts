import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, MenuController, ViewController, ModalController } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Jsonp, Http, URLSearchParams, Response, Headers, RequestOptions } from '@angular/http';
import {TermAndConditionsPage } from '../term-and-condition/term-and-condition';

/*
  Generated class for the Membership page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-membership',
  templateUrl: 'membership.html'
})
export class MembershipPage {
  public companiesData: any;
  private membershipFormData: any;

  public errorMsg: any;
  public successMsg: any;

  public http: any;
  public jsonp: Jsonp;

  public businesstijd_register: Number;

  public bestaand_bedrijf: Boolean;
  public nieuw_bedrijf: Boolean;

  public messages: any;
  public errors: any;

  public membershipForm = this.membershipFormBuilder.group({
      'businesstijd_register': ['', Validators.required],
      'businesstijd_existing_company': '',
      'company_name': '',
      'Adres_5572': '',
      'Postcode_5572': '',
      'Plaats_5572': '',
      'phone_number_5572': '',
      'Fax_5572': '',
      'company_email': '',
      'Website_5572': '',
      'btiusername': '',
      'username': ['', Validators.required],
      'user_phone_number_5572': '',
      'user_email': '',
      'machtiging': '',
      'Rekeningnummer_5572': '',
      'maandag_5572': '',
      'dinsdag_5572': '',
      'Woensdag_5572': '',
      'donderdag_5572': '',
      'vrijdag_5572': '',
      'zaterdag_5572': '',
      'zondag_5572': '',
      'description': '',
      'terms_and_conditions': 'accepteren',
    });

  constructor(navCtrl: NavController, navParams: NavParams, public membershipFormBuilder: FormBuilder, http: Http, jsonp: Jsonp, public loadginCtrl: LoadingController, public viewModel: ModalController) {
    
    let loadingPopup = loadginCtrl.create({
      content: "Data laden..."
    });

    loadingPopup.present();    

    this.nieuw_bedrijf = true;
    this.bestaand_bedrijf = false;

    http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/registered_companies').map(res => res.json()).subscribe(data => {
      this.companiesData = data;
      loadingPopup.dismiss();
    },
    err => {
      this.errorMsg = "Kan geen bedrijven gegevens op te halen";
      loadingPopup.dismiss();
    });

    this.http = http;
  }

  // submitMembership(memberForm){
  //   console.log(memberForm);
  // }
  submitMembership(value: Object){
    
    let loadingPopup = this.loadginCtrl.create({
      content: "Het indienen van Contact Aanvraag..."
    });

    loadingPopup.present();

    const body = new URLSearchParams();

    Object.keys(value).forEach(key => {
      body.set(key,value[key]);
    });

    let headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');

    this.http.post('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/register_members', body.toString(), {
      headers: headers,
    }).map(res=> res.json()).subscribe(data=> {
      if(data.status == 'success'){
        this.errorMsg = false;
        this.messages = data.message;
        loadingPopup.dismiss();
        alert(this.messages);
      }else if(data.status == 'error'){
        this.successMsg = false;
        this.errors = data.errors;
        loadingPopup.dismiss();
      }
    },
    err=>{
      this.errorMsg = "Kan lidmaatschap niet posten";
    })

    
  }

  showBedrijf(){

    if(this.businesstijd_register == 1){
      this.nieuw_bedrijf = true;
      this.bestaand_bedrijf = false;
    }

    if(this.businesstijd_register == 2){
      this.bestaand_bedrijf = true;
      this.nieuw_bedrijf = false;
    }
    console.log(this.businesstijd_register);
  }
  openModal() {
    let myModal = this.viewModel.create(TermAndConditionsPage);
    myModal.present();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad MembershipPage');
  }

}
