import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, MenuController } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Jsonp, Http, URLSearchParams, Response, Headers, RequestOptions } from '@angular/http';

/*
  Generated class for the Contact page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  public contactForm = this.contactFormBuilder.group({
    'name' : ['', Validators.compose([Validators.required])],
    'email' : ['', Validators.compose([Validators.required])],
    'phone': [''],
    'subject': ['', Validators.compose([Validators.required])],
    'message': ['', Validators.compose([Validators.required])]
  });

  constructor(public navCtrl: NavController, public navParams: NavParams, public contactFormBuilder: FormBuilder, public http: Http, public jsonp: Jsonp, public loadingCtrl: LoadingController) {

  }

  submitRequest(value: Object){
    let loadingPopup = this.loadingCtrl.create({
      content: 'Het indienen van aanvragen, even geduld aub'
    });

    loadingPopup.present();

    const body = new URLSearchParams();

    Object.keys(value).forEach(key => {
      body.set(key,value[key]);
    });

    let headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    alert(body);

    this.http.post('http://demo.presstigers.com/businesstijd/wp-json/presstigers_rest_endpoints/v2/contact_us', body.toString(), {
      headers: headers
    }).map(res=> res.json()).subscribe(data=> {
      loadingPopup.dismiss();
      alert(data.message);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ContactPage');
  }

}
