import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, MenuController } from 'ionic-angular';
import { Http } from '@angular/http';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import { NieuwsDetailPage } from '../nieuws-detail/nieuws-detail';

/*
  Generated class for the Nieuws page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-nieuws',
  templateUrl: 'nieuws.html'
})
export class NieuwsPage {

  public nieuws:any;
  public searchNieuws:any;
  public blog:any=NieuwsDetailPage;
  public error_message:any = '';
  public blogDetail:any;
  public page:any=1;
  public lastSearchString: any='';

  constructor(public http: Http, public loadingCtrl: LoadingController, public navctr: NavController, public menu: MenuController, public localStorage: Storage) {
    this.localStorage.get('nieuwsData').then((nieuwsData) => {
      this.nieuws = nieuwsData.data;
      this.page = nieuwsData.nieuwsPage;
      this.searchNieuws = this.nieuws;
    }).catch(() => {
      // Create the popup
      let loadingPopup = this.loadingCtrl.create({
        content: 'Data laden...'
      });
      // Show the popup
      loadingPopup.present();

      this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/posts').map(res => res.json()).subscribe(data => {
        this.nieuws = data;
        this.page = 2;
        this.localStorage.set('nieuwsData', {'data': data, 'nieuwsPage': this.page});
        this.searchNieuws = this.nieuws;
        loadingPopup.dismiss();
      },
      err => {
          loadingPopup.dismiss();
          this.error_message = 'er is iets fout gegaan!';
      });
    });
  }

  viewDetail(data){
    this.navctr.push(this.blog, {
      blogDetail: data
    });
  }

  searchData(ev: any){
    let val = ev.target.value;
    if(val != undefined){
      if(val.trim() == ''){
        this.initializeSearchItems();
      }

      if(val && val.trim() != ''){
        this.nieuws = this.nieuws.filter((nieuwsData) => {
          this.lastSearchString = val;
          return ( nieuwsData.post_title.toLowerCase().indexOf( val.toLowerCase() ) > -1 );
        });
      }
    }    
  }

  clearSearch(ev: any){
    console.log('clear called...');
    this.initializeSearchItems();
    return false;
  }

  searchKeyupEvent(ev: any){
    let val = ev.target.value;
    if(val.length < this.lastSearchString.length){
      this.initializeSearchItems();
    }
  }

  initializeSearchItems(){
    this.localStorage.get('nieuwsData').then((nieuwsData) => {
      this.nieuws = nieuwsData.data;
    }).catch(() => {
      this.nieuws = this.searchNieuws;
    });
  }

  doRefresh(refresher?){
    // Create the popup
    let loadingPopup = this.loadingCtrl.create({
      content: 'Data laden...'
    });
    // Show the popup
    loadingPopup.present();

    this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/posts').map(res => res.json()).subscribe(data => {
      this.page = 2;
      this.nieuws = data;
      this.localStorage.set('nieuwsData', {'data': data, 'nieuwsPage': this.page});
      this.searchNieuws = this.nieuws;
      refresher.complete();
      loadingPopup.dismiss();
    },
    err => {
        loadingPopup.dismiss();
        refresher.complete();
        this.error_message = 'er is iets fout gegaan!';
    });
  }

  loadMoreEvents(infiniteScroll){
    setTimeout(()=>{
      if(this.page > 1){
        // Create the popup
        let loadingPopup = this.loadingCtrl.create({
          content: 'Data laden...'
        });
        // Show the popup
        loadingPopup.present();

        this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/posts?paged='+this.page).map(res => res.json()).subscribe(data => {
          this.nieuws = this.nieuws.concat(data);
          infiniteScroll.complete();
          loadingPopup.dismiss();
          if(data.length){
            this.page++;
          }else{
            this.page=0;
          }
          this.localStorage.set('nieuwsData', {'data': this.nieuws, 'nieuwsPage': this.page});
          this.searchNieuws = this.nieuws;
        },
        err => {
          infiniteScroll.complete();
          loadingPopup.dismiss();
          this.error_message = 'er is iets fout gegaan!';
        });
      }else{
        infiniteScroll.complete();
      }    
    },500);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NieuwsPage');
  }

}
