import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, LoadingController } from 'ionic-angular';

/*
  Generated class for the GallerySlides page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-gallery-slides',
  templateUrl: 'gallery-slides.html'
})

export class GallerySlidesPage {

  public galleryTitle: any;
  public slideImages: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewController: ViewController) {
    this.galleryTitle = this.navParams.get('title');
    this.slideImages = this.navParams.get('slides');
  }

  dismissModal(){
    this.viewController.dismiss();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad GallerySlidesPage');
  }

}
