import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, LoadingController } from 'ionic-angular';
import { Jsonp, Http, Headers, URLSearchParams } from '@angular/http';
import { FormGroup, FormBuilder, FormControl, Validators, } from '@angular/forms';

/*
  Generated class for the NieuwsbriefRegistreren page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-nieuwsbrief-registreren',
  templateUrl: 'nieuwsbrief-registreren.html'
})
export class NieuwsbriefRegistrerenPage {
  
  public mailchimpRes: any;
  public mailchimpResErr: any;


  public newsletterForm = this.newsletterFormBuilder.group({
    'newletterEmail': ['', Validators.required]
  });
  
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, public newsletterFormBuilder: FormBuilder, public http: Http, public loadingCtrl: LoadingController) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad NieuwsbriefRegistrerenPage');
  }

  dismissModal(){
    this.viewCtrl.dismiss();
  }

  addSubscription(value: Object){
    const body = new URLSearchParams();
    Object.keys(value).forEach(key => {
      body.set(key,value[key]);
    });
    
    let mailchimpHeaders = new Headers();
    mailchimpHeaders.append('Content-Type', 'application/x-www-form-urlencoded');
    

    let loadingPopup = this.loadingCtrl.create({
      content: "Even geduld aub..."
    });

    loadingPopup.present();

    console.log(body);

    this.http.post(
      'http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/newsletter_subscription', 
      body.toString(), 
      {headers: mailchimpHeaders}
    ).map( res => res.json() ).subscribe( data => {
      loadingPopup.dismiss();
      console.log('dataaa',data);
      alert(data.data);
    }, err => {
      console.log('error', err);
      loadingPopup.dismiss();
      alert('Kan niet abonneren. Probeer het opnieuw.');
    });


  }

}
