import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the NieuwsDetail page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-nieuws-detail',
  templateUrl: 'nieuws-detail.html'
})
export class NieuwsDetailPage {

  public blogDetail:any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.blogDetail = navParams.get('blogDetail');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NieuwsDetailPage');
  }

}
