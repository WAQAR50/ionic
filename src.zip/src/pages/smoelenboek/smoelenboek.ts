import { Component } from '@angular/core';
/*import { NavController, NavParams, LoadingController, MenuController } from 'ionic-angular';*/
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { Http } from '@angular/http';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import { SmoelenboekDetailPage } from '../smoelenboek-detail/smoelenboek-detail';

/*
  Generated class for the Smoelenboek page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-smoelenboek',
  templateUrl: 'smoelenboek.html'
})
export class SmoelenboekPage {

  public users: any;
  public searchUsers: any;
  public errorMsg: any;
  public userDetail: any = SmoelenboekDetailPage;

  public lastSearchString: any='';

  public usersOffset: number = 0;

  constructor(public navCtrl: NavController, public navParams: NavParams, public http: Http, public loadingCtrl: LoadingController, public localStorage: Storage) {
    this.localStorage.get('usersData').then((usersData) => {
      this.users = usersData.data;
      this.usersOffset = usersData.usersOffset;
      this.searchUsers = this.users;
    }).catch(() => {
      // Create the popup
      let loadingPopup = this.loadingCtrl.create({
        content: 'Data laden...'
      });
      // Show the popup
      loadingPopup.present();

      this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/all_company_users').map(res => res.json()).subscribe(data => {
        this.users = data;
        this.usersOffset = 5;
        this.localStorage.set(`usersData`, {'data': data, 'usersOffset': this.usersOffset});
        this.searchUsers = this.users;
        loadingPopup.dismiss();
      },
      err => {
          loadingPopup.dismiss();
          this.errorMsg = 'er is iets fout gegaan!';
      });
    });
  }

  doRefresh(refresher?){
    // Create the popup
    let loadingPopup = this.loadingCtrl.create({
      content: 'Data laden...'
    });
    // Show the popup
    loadingPopup.present();

    this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/all_company_users').map(res => res.json()).subscribe(data => {
      this.users = data;
      this.usersOffset = 5;
      this.localStorage.set(`usersData`, {'data': data, 'usersOffset': this.usersOffset});
      this.searchUsers = this.users;
      refresher.complete();
      loadingPopup.dismiss();
    },
    err => {
        refresher.complete();
        loadingPopup.dismiss();
        this.errorMsg = 'er is iets fout gegaan!';
    });
  }

  loadMoreUsers(infiniteScroll){
    setTimeout(()=>{
      if(this.usersOffset > 4){
        // Create the popup
        let loadingPopup = this.loadingCtrl.create({
          content: 'Data laden...'
        });
        // Show the popup
        loadingPopup.present();

        this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/all_company_users?offset='+this.usersOffset).map(res => res.json()).subscribe(data => {
          this.users = this.users.concat(data);
          infiniteScroll.complete();
          loadingPopup.dismiss();
          if(data.length){
            this.usersOffset = this.usersOffset + 5;
          }else{
            this.usersOffset = 0;
          }
          this.localStorage.set(`usersData`, {'data': this.users, 'usersOffset': this.usersOffset});
          this.searchUsers = this.users;
        },
        err => {
          infiniteScroll.complete();
          loadingPopup.dismiss();
          this.errorMsg = 'er is iets fout gegaan!';
        });
      }else{
        infiniteScroll.complete();
      }    
    },500);
  }

  viewDetail(user){
    this.navCtrl.push(this.userDetail, {
      user: user
    });
    return false;
  }
  
  searchData(ev: any){
    let val = ev.target.value;
    if(val != undefined){
      if(val.trim() == ''){
        this.initializeSearchItems();
      }

      if(val && val.trim() != ''){
        this.users = this.users.filter((userData) => {
          this.lastSearchString = val;
          return ( userData.data.display_name.toLowerCase().indexOf( val.toLowerCase() ) > -1 );
        });
      }
    }    
  }

  clearSearch(ev: any){
    this.initializeSearchItems();
    return false;
  }

  searchKeyupEvent(ev: any){
    let val = ev.target.value;
    if(val.length < this.lastSearchString.length){
      this.initializeSearchItems();
    }
  }

  initializeSearchItems(){
    this.localStorage.get('usersData').then((usersData) => {
      this.users = usersData.data;
    }).catch(() => {
      this.users = this.searchUsers;
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SmoelenboekPage');
  }

}
