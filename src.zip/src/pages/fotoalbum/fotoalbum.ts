import { Component } from '@angular/core';
/*import { NavController, NavParams, LoadingController, MenuController } from 'ionic-angular';*/
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { Http } from '@angular/http';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import { GalleryDetailPage } from '../gallery-detail/gallery-detail'

/*
  Generated class for the Fotoalbum page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-fotoalbum',
  templateUrl: 'fotoalbum.html'
})
export class FotoalbumPage {

  public fotoGallery: any;
  public errorMsg: any;
  public galleryDetail: any = GalleryDetailPage;

  constructor(public navCtrl: NavController, public navParams: NavParams, public http: Http, public loadingCtrl: LoadingController, public localStorage: Storage) {
   
      // Create the popup
      let loadingPopup = this.loadingCtrl.create({
        content: 'Data laden...'
      });
      // Show the popup
      loadingPopup.present();

      this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/gallery_images').map(res => res.json()).subscribe(data => {
        this.fotoGallery = data;
        this.localStorage.set(`galleryData`, data);
        loadingPopup.dismiss();
      },
      err => {
          loadingPopup.dismiss();
          this.errorMsg = 'er is iets fout gegaan!';
      });
   
   
   
    this.localStorage.get('galleryData').then((galleryData) => {
      this.fotoGallery = galleryData;
    }).catch(() => {
      // Create the popup
      let loadingPopup = this.loadingCtrl.create({
        content: 'Data laden...'
      });
      // Show the popup
      loadingPopup.present();

      this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/gallery_images').map(res => res.json()).subscribe(data => {
        this.fotoGallery = data;
        this.localStorage.set(`galleryData`, data);
        loadingPopup.dismiss();
      },
      err => {
          loadingPopup.dismiss();
          this.errorMsg = 'er is iets fout gegaan!';
      });
    });
    
  }

  doRefresh(refresher?){
    // Create the popup
    let loadingPopup = this.loadingCtrl.create({
      content: 'Data laden...'
    });
    // Show the popup
    loadingPopup.present();

    this.http.get('http://businesstijd.demo2.appelit.com/wp-json/presstigers_rest_endpoints/v2/gallery_images').map(res => res.json()).subscribe(data => {
      this.fotoGallery = data;
      this.localStorage.set(`galleryData`, data);
      refresher.complete();
      loadingPopup.dismiss();
    },
    err => {
      refresher.complete();
      loadingPopup.dismiss();
      this.errorMsg = 'er is iets fout gegaan!';
    });
  }

  viewGallery(gallery){
    this.navCtrl.push(this.galleryDetail, {
      galleryImages: gallery
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FotoalbumPage');
  }

}
