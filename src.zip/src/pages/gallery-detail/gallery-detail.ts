import { Component } from '@angular/core';
import { NavController, NavParams, ModalController } from 'ionic-angular';
import { PhotoViewer } from 'ionic-native';

import { GallerySlidesPage } from '../gallery-slides/gallery-slides';

/*
  Generated class for the GalleryDetail page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/

@Component({
  selector: 'page-gallery-detail',
  templateUrl: 'gallery-detail.html'
})
export class GalleryDetailPage {

  public galleryDetail: any;
  public gallerySlide: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public modal: ModalController) {
    this.galleryDetail = navParams.get('galleryImages');
    console.log(this.galleryDetail);
  }

  showImage(image, alttext){
    //PhotoViewer.show(image,alttext);
     console.log('ionViewDidLoad', image);
  }

  showImages(slideImages, galleryTitle){
    let gallerySlideModal = this.modal.create(GallerySlidesPage, {slides: slideImages, title: galleryTitle});
    gallerySlideModal.present();
     console.log('ionViewDidLoad', gallerySlideModal);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad GalleryDetailPage');
  }

}
